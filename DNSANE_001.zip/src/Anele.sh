#!/bin/bash

# System call times to test
system_call_times=("5" "10" "15")
# Context switching times to test
context_switch_times=("20" "30" "40")

# Iterate over each combination of system call time and context switch time
for sys_call_time in "${system_call_times[@]}"; do
    for context_switch_time in "${context_switch_times[@]}"; do
        # Write the input configuration to the .inp file
        echo "workload/workloadConfig.cfg" > input_file.inp
        echo "FCFSKernel" >> input_file.inp
        echo "$sys_call_time" >> input_file.inp
        echo "$context_switch_time" >> input_file.inp
        echo "output/FCFS_${sys_call_time}_${context_switch_time}.txt" >> input_file.inp

        # Run the Java simulator using the .inp file as input
        java Simulate input_file.inp
#
#        # Process the tracing file using the Python script
#        python process_tracing_file.py
    done
done