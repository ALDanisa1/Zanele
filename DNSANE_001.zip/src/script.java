import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class script {
    public static void main(String[] args) {
        // Define the number of times to run the simulation
        int numRuns = 10;

        // Define the command to run the Java simulator
        String javaCommand = "Java Simulate";

        // Run the Java simulator multiple times
        for (int i = 0; i < numRuns; i++) {
            System.out.println("Running process: " + (i + 1));

            try {
                Process process = Runtime.getRuntime().exec(javaCommand);
                int exitCode = process.waitFor();

                // Read the output of the Java simulator
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println(line);
                }

                // Check if any errors occurred during execution
                BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
                String errorLine;
                while ((errorLine = errorReader.readLine()) != null) {
                    System.err.println(errorLine);
                }

                if (exitCode != 0) {
                    System.err.println("Error occurred while running the Java simulator. Exit code: " + exitCode);
                }
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println("Process " + (i + 1) + " completed.");
            System.out.println();
        }
    }
}
