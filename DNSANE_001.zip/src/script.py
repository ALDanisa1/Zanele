import subprocess

# Define the number of times to run the simulation
num_runs = 10

# Define the command to run the Java simulator
java_command = 'java Simulate'

# Run the Java simulator multiple times
for i in range(num_runs):
    print(f'Running process: {i + 1}')
    try:
        process = subprocess.Popen(java_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        stdout, stderr = process.communicate()
        exit_code = process.returncode

        # Print the output of the Java simulator
        print(stdout.decode())
        if stderr:
            print(stderr.decode())

        if exit_code != 0:
            print(f'Error occurred while running the Java simulator. Exit code: {exit_code}')
    except subprocess.CalledProcessError as e:
        print(f'Error occurred while running the Java simulator: {e}')
    except Exception as e:
        print(f'An error occurred: {e}')

    print(f'Process {i + 1} completed.\n')