/**
* This package contains data types for creating scheduling simulations.
*/
package simulator;
